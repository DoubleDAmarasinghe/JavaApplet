import java.util.*;
import java.awt.*;
import java.applet.*;
public class dda1 extends Applet
{
	int centerX,centerY,maxX,maxY;
	
	void intgr()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	void drawLine(Graphics g,int x1,int y1,int x2,int y2)
	{
		float dx,dy,steps;
		float Xinc,Yinc,x,y;
		dx=x2-x1;
		dy=y2-y1;
		x=x1;
		y=y1;
		if(Math.abs(dx)>Math.abs(dy))
		{
			steps=Math.abs(dx);
		}
		else
		{
			steps=Math.abs(dy);
		}
		Xinc=dx/steps;
		Yinc=dy/steps;
		
		g.fillOval((int)x,(int)y,5,5);
		for(int i=1;i<=steps;i++)
		{
			x=x+Xinc;
			y=y+Yinc;
			g.fillOval((int)x,(int)y,5,5);
		}
	}
	
	public void paint(Graphics g)
	{
		intgr();
		drawLine(g,centerX,centerY,centerX+100,centerY);
		drawLine(g,centerX,centerY,centerX-100,centerY);
		drawLine(g,centerX,centerY,centerX,centerY+100);
		drawLine(g,centerX,centerY,centerX,centerY-100);
		drawLine(g,centerX,centerY,centerX+100,centerY-100);
		drawLine(g,centerX,centerY,centerX+100,centerY+100);
		drawLine(g,centerX,centerY,centerX-100,centerY-100);
		drawLine(g,centerX,centerY,centerX-100,centerY+100);
		drawLine(g,centerX,centerY,centerX+100,centerY-1000);
		drawLine(g,centerX,centerY,centerX+1000,centerY-100);
	}
}
/*
<applet code="dda1.class" width="1000" height="1000"></applet>
*/