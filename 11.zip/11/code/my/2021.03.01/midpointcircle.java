import java.util.*;
import java.awt.*;
import java.applet.*;
public class midpointcircle extends Applet
{
	int centerX,centerY,maxX,maxY;
	
	void intgr()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	void circle(Graphics g,int r)
	{
		int p,x,y;
		
		x=0;
		y=r;
		p=1-r;
		
		while(x<=y)
		{
			g.fillOval((int)x,(int)y,5,5);
			g.fillOval(-(int)x,(int)y,5,5);
			g.fillOval((int)x,-(int)y,5,5);
			g.fillOval(-(int)x,-(int)y,5,5);
			x++;
			if(p<0)
			{
				p=p+2*x+3;
			}
			else
			{
				p=p+2*(x-y)+5;
				y--;
			}
			x++;
		}
	}
	
	
	public void paint(Graphics g)
	{
		intgr();
		circle(g,50);
	}
}
/*
<applet code="midpointcircle.class" width="1000" height="1000"></applet>
*/