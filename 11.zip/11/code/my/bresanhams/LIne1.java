import java.util.*;
import java.awt.*;
import java.applet.*;
public class Line1 extends Applet
{
	 int centerX,centerY,maxX,maxY;
	 
	 void intrg()
	 {
		 Dimension d;
		 d=getSize();
		 maxX=d.width;
		 maxY=d.height;
		 centerX=maxX/2;
		 centerY=maxY/2;
	 }
	 
	 void drawLine(Graphics g,int x1,int y1,int x2,int y2)
	 {
		 int dx,dy,p,x,y;
		 
		 dx=x2-x1;
		 dy=y2-y1;
		 x=x1;
		 y=y1;
		 
		 p=2*dy-dx;
		 
		 while(x<=x2)
		 {
			 g.fillOval((int)x,(int)y,5,5);
			 x++;
			 if(p<0)
			 {
				 p=p+2*dy;
			 }
			 else
			 {
				 p=p+2*dy-2*dx;
				 y++;
			 }
		 }
	 }
	 
	 public void paint(Graphics g)
	 {
		 intrg();
		 drawLine(g,centerX-100,centerY-100,centerX+100,centerY);
		 drawLine(g,centerX,centerY,centerX+100,centerY+50000);
	 }
}

/*<applet code="Line1.class" width="1000" height="1000"></applet>*/