import java.util.*;
import java.awt.*;
import java.applet.*;
public class Line3 extends Applet
{
	int centerX,centerY,maxX,maxY;
	
	void intgr()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	void drawLine(Graphics g,int x1,int y1,int x2,int y2)
	{
		int dx,dy,x,y,p;
		
		dx=x2-x1;
		dy=y2-y1;
		x=x1;
		y=y1;
		if(Math.abs(dx)>Math.abs(dy))
		{
			
			p=2*dy-dx;
			while(x<=x2)
			{
				g.fillOval((int)x,(int)y,5,5);
				x++;
				
				if(p<0)
				{
					p=p+2*dy;
				}
				else
				{
					p=p+2*dy-2*dx;
					y++;
				}
			}
		}
		else if(Math.abs(dx)<Math.abs(dy))
		{
			
			p=2*dx-dy;
			while(y<=y2)
			{
				g.fillOval((int)x,(int)y,5,5);
				y++;
				if(p<0)
				{
					p=p+2*dx;
				}
				else
				{
					p=p+2*dx-2*dy;
					x++;
				}
			}
		}
		else
		{
			while(x<=x2)
			{
				g.fillOval((int)x,(int)y,5,5);
				x++;
				y++;
			}
		}
	}
	
	public void paint(Graphics g)
	{
		intgr();
		drawLine(g,centerX,centerY,centerX+100,centerY);
		//drawLine(g,centerX+100,centerY,centerX+200,centerY+500);
		//drawLine(g,centerX+100,centerY,centerX+600,centerY+200);
		drawLine(g,centerX+100,centerY,centerX+500,centerY-400);
	}
}

/*<applet code="Line3.class" width="1000" height="1000"></applet>*/