import java.util.*;
import java.awt.*;
import java.applet.*;
public class Line4 extends Applet
{
	int centerX,centerY,maxX,maxY;
	
	void intgr()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	void drawLine(Graphics g,int x1,int y1,int x2,int y2)
	{
		int dx,dy,x,y,p;
		
		dx=x2-x1;
		dy=y2-y1;
		x=x1;
		y=y1;
		if(Math.abs(dx)>Math.abs(dy))
		{
			p=2*dy-dx;
			
			if(x1<x2)
			{
				while(x<=x2)
				{
					g.fillOval((int)x,(int)y,5,5);
					x++;
					if(p<0)
					{
						p=p+2*dy;
					}
					else
					{
						p=p+2*dy-2*dx;
						y=getY(y1,y2,y);
					}
				}
			}
			else
			{
				while(x>=x2)
				{
					g.fillOval((int)x,(int)y,5,5);
					x--;
					if(p<0)
					{
						p=p+2*dy;
					}
					else
					{
						p=p+2*dy-2*dx;
						y=getY(y1,y2,y);
					}
				}
			}
		}
		else
		{
			p=2*dx-dy;
			
			if(y1<y2)
			{
				while(y<=y2)
				{
					g.fillOval((int)x,(int)y,5,5);
					y++;
					if(p<0)
					{
						p=p+2*dx;
					}
					else
					{
						p=p+2*dx-2*dy;
						x=getX(x1,x2,x);
					}
				}
			}
			else
			{
				while(y>=y2)
				{
					g.fillOval((int)x,(int)y,5,5);
					y--;
					if(p<0)
					{
						p=p+2*dx;
					}
					else
					{
						p=p+2*dx-2*dy;
						x=getX(x1,x2,x);
					}
				}
			}
		}
		
	}
	
	public void paint(Graphics g)
	{
		intgr();
		
		drawLine(g,centerX,centerY,centerX+50,centerY);
		drawLine(g,centerX,centerY,centerX,centerY+50);
		drawLine(g,centerX,centerY+50,centerX+50,centerY+500);
		drawLine(g,centerX,centerY+50,centerX+400,centerY+100);
	}
	
	int getY(int y1,int y2,int y)
	{
		if(y1<y2)
		{
			return ++y;
		}
		else if(y1>y2)
		{
			return --y;
		}
		else
		{
			return y;
		}
		
	}
	
	int getX(int x1,int x2,int x)
	{
		if(x1<x2)
		{
			return ++x;
		}
		else if(x1>x2)
		{
			return --x;
		}
		else
		{
			return x;
		}
	}
}
/*
<applet code="Line4.class" width="1000" height="1000"></applet>
*/