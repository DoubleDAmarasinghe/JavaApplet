import java.util.*;
import java.awt.*;
import java.applet.*;
public class Line6 extends Applet
{
	int maxX,maxY,centerX,centerY;
	
	void intgr()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	void drawLine(Graphics g,int x1,int y1,int x2,int y2)
	{
		int dx,dy,x,y,p;
		
		dx=Math.abs(x2-x1);
		dy=Math.abs(y2-y1);
		x=x1;
		y=y1;
		
		if(dx>dy)
		{
			p=2*dy-dx;
			
			if(x1<x2)
			{
				
				while(x<=x2)
				{
					g.fillOval((int)x,(int)y,5,5);
					x++;
					if(p<0)
					{
						p=p+2*dy;
					}
					else
					{
						p=p+2*dy-2*dx;
						y=getY(y,y1,y2);
						
					}
				}
			}
			else
			{
				while(x>=x2)
				{
					g.fillOval((int)x,(int)y,5,5);
					x--;
					if(p<0)
					{
						p=p+2*dy;
					}
					else
					{
						p=p+2*dy-2*dx;
						y=getY(y,y1,y2);
					}
				}
			}
		}
		else
		{
			p=2*dx-dy;
			
			if(y1<y2)
			{
				while(y<=y2)
				{
					g.fillOval((int)x,(int)y,5,5);
					y++;
					if(p<0)
					{
						p=p+2*dx;
					}
					else
					{
						p=p+2*dx-2*dy;
						x=getX(x,x1,x2);
					}
				}
			}
			else
			{
				while(y>=y2)
				{
					g.fillOval((int)x,(int)y,5,5);
					y--;
					if(p<0)
					{
						p=p+2*dx;
					}
					else
					{
						p=p+2*dx-2*dy;
						x=getX(x,x1,x2);
					}
				}
			}
		}
	}
	
	public void paint(Graphics g)
	{
		intgr();
		drawLine(g,centerX,centerY,centerX,centerY);
		drawLine(g,centerX,centerY,centerX+100,centerY);
		drawLine(g,centerX,centerY,centerX,centerY+100);
		drawLine(g,centerX,centerY,centerX,centerY-100);
		drawLine(g,centerX,centerY,centerX-100,centerY);
		drawLine(g,centerX,centerY,centerX+100,centerY-100);
		drawLine(g,centerX,centerY,centerX+100,centerY+100);
		drawLine(g,centerX,centerY,centerX-100,centerY-100);
		drawLine(g,centerX,centerY,centerX-100,centerY+100);
		drawLine(g,centerX,centerY,centerX+100,centerY-200);
		drawLine(g,centerX,centerY,centerX+200,centerY-100);
		drawLine(g,centerX,centerY,centerX+100,centerY+200);
		drawLine(g,centerX,centerY,centerX+200,centerY+100);
		drawLine(g,centerX,centerY,centerX-100,centerY+200);
		drawLine(g,centerX,centerY,centerX-200,centerY+100);
		drawLine(g,centerX,centerY,centerX-200,centerY-100);
		drawLine(g,centerX,centerY,centerX-100,centerY-200);
	}
	
	int getY(int y,int y1,int y2)
	{
		if(y1<y2)
		{
			return ++y;
		}
		else if(y2<y1)
		{
			return --y;
		}
		else
			return y;
	}
	int getX(int x,int x1,int x2)
	{
		if(x1<x2)
		{
			return ++x;
		}
		else if(x2<x1)
		{
			return --x;
		}
		else
			return x;
	}
}