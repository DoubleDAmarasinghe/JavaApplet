import java.util.*;
import java.awt.*;
import java.applet.*;
public class circle2 extends Applet
{
	int maxX,maxY,centerX,centerY;
	
	void intgr()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	void circle(Graphics g,int x1,int y1,int r)
	{
		int p,x,y;
		
		p=3-2*r;
		x=0;
		y=r;
		
		while(x<=y)
		{
			g.fillOval(x+x1,y+y1,5,5);
			g.fillOval(-x+x1,y+y1,5,5);
			g.fillOval(x+x1,-y+y1,5,5);
			g.fillOval(-x+x1,-y+y1,5,5);
			
			g.fillOval(y+x1,x+y1,5,5);
			g.fillOval(-y+x1,x+y1,5,5);
			g.fillOval(y+x1,-x+y1,5,5);
			g.fillOval(-y+x1,-x+y1,5,5);
			
			if(p>=0)
			{
				x++;
				y--;
				
				p=p+4*(x-y)+10;
			}
			else
			{
				x++;
				y=y;
				
				p=p+4*x+6;
			}
		}
	}
	
	public void paint(Graphics g)
	{
		intgr();
		circle(g,centerX,centerY,100);
		circle(g,centerX,centerY,200);
		circle(g,100,100,100);
	}
}