import java.util.*;
import java.awt.*;//for graphic capabilities
import java.applet.*;
public class Line extends Applet
{
	static int centerX,centerY,maxX,maxY;
	
	//function for the draw the line at the middle of the applet window
	
	void initgr()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	
	void drawLine(Graphics g,int x1,int y1,int x2,int y2)//put pixel for line points
	{
		int dx,dy,steps;
		
		float Xinc,Yinc,x,y;
		
		dx=x2-x1;
		dy=y2-y1;
		
		if(Math.abs(dx)>Math.abs(dy))
		{
			steps=Math.abs(dx);
		}
		else
		{
			steps=Math.abs(dy);
		}
		
		Xinc=dx/steps;
		Yinc=dy/steps;
		
		x=x1;
		y=y1;
		for(int i=1;i<=steps;i++)
		{
			x=x+Xinc;
			y=y+Yinc;
			
			g.fillOval((int)x,(int)y,5,5);//convert float into int using narrowing technique
		}
		
	}
	
	public void paint(Graphics g)
	{
		initgr();
		drawLine(g,centerX,centerY,centerX+100,centerY);
		drawLine(g,centerX,centerY,centerX-100,centerY);
		drawLine(g,centerX,centerY,centerX,centerY+100);
		drawLine(g,centerX,centerY,centerX,centerY-100);
		drawLine(g,centerX,centerY,centerX+100,centerY-100);
		drawLine(g,centerX,centerY,centerX+100,centerY+100);
		drawLine(g,centerX,centerY,centerX-100,centerY-100);
		drawLine(g,centerX,centerY,centerX-100,centerY+100);
		drawLine(g,centerX,centerY,centerX+100,centerY-1000);
	}
	
}

/*<applet code="Line.class" width="1000" height="1000">
</applet>
*/