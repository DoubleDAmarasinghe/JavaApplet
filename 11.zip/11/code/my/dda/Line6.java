import java.util.*;
import java.awt.*;
import java.applet.*;

public class Line6 extends Applet
{
	int maxX,maxY,centerX,centerY;
	
	void intgr()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	void drawLine(Graphics g,int x1,int y1,int x2,int y2)
	{
		double dx,dy,steps;
		double Xinc,Yinc,x,y;
		
		dx=x2-x1;
		dy=y2-y1;
		
		if(Math.abs(dx)>Math.abs(dy))
		{
			steps=Math.abs(dx);
		}
		else
		{
			steps=Math.abs(dy);
		}
		
		Xinc=dx/steps;
		Yinc=dy/steps;
		
		x=x1;
		y=y1;
		
		for(int i=1;i<=steps;i++)
		{
			g.fillOval((int)x,(int)y,5,5);
			x=x+Xinc;
			y=y+Yinc;
		}
		
	}
	
	public void paint(Graphics g)
	{
		intgr();
		drawLine(g,centerX-200,centerY,centerX+200,centerY);
		drawLine(g,centerX+200,centerY,centerX+400,centerY-400);
		drawLine(g,centerX+400,centerY-400,centerX,centerY-400);
		drawLine(g,centerX,centerY-400,centerX-200,centerY);
	}
}

/*<applet code="Line6.class" width="1000" height="1000"></applet>*/