import java.util.*;
import java.awt.*;
import java.applet.*;
public class circle2 extends Applet
{
	int maxX,maxY,centerX,centerY;
	
	void intgr()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	void drawCircle(Graphics g,int x1,int y1,int r)
	{
		int x,y,p;
		
		p=1-r;
		x=0;
		y=r;
		
		while(x<=y)
		{
			g.fillOval(x+x1,y+y1,5,5);
			g.fillOval(-x+x1,y+y1,5,5);
			g.fillOval(x+x1,-y+y1,5,5);
			g.fillOval(-x+x1,-y+y1,5,5);
			
			g.fillOval(y+x1,x+y1,5,5);
			g.fillOval(y+x1,-x+y1,5,5);
			g.fillOval(-y+x1,x+y1,5,5);
			g.fillOval(-y+x1,-x+y1,5,5);
			
			if(p>=0)
			{
				x++;
				y--;
				
				p=p+2*(x+1)-2*(y-1);
			}
			else
			{
				x++;
				y=y;
				
				p=p+2*(x+1);
			}
			
		}
	}
	
	public void paint(Graphics g)
	{
		intgr();
		drawCircle(g,centerX,centerY,100);
		drawCircle(g,centerX,centerY,200);
	}
}/*<applet code="circle2.class" width="1000" height="1000"></applet>*/