import java.applet.*;
import java.awt.*;
import java.util.*;

	public class rotation extends Applet
	{
		int centerX, centerY, dGrid = 1, maxX, maxY;
		void initgr() {
		Dimension d;
		d = getSize();
		maxX = d.width - 1; 
		maxY = d.height - 1;
		centerX = maxX/2; centerY = maxY/2;
		}
	void rotate(int a[][], int n, int x_pivot, int y_pivot,int angle)
	{
		int i = 0;
		while (i < n) {
		int x_shifted = a[i][0]- x_pivot;
        int y_shifted = a[i][1]- y_pivot;
		a[i][0]=x_pivot+(int)(x_shifted* Math.sin(angle)- y_shifted* Math.sin(angle));
		a[i][1]=y_pivot+(int)(x_shifted* Math.cos(angle)+ y_shifted* Math.cos(angle));
		i++;
	}
	}
	public void paint(Graphics g) 
	{
	initgr();
	int size1 =6; 
	int points_list1[][] = {{0,0},{200,0 },{0,0},{0,-200},{200,0},{0,-200}};
	
	g.drawLine(centerX+points_list1[0][0],centerY+points_list1[0][1],centerX+points_list1[1][0],centerY+points_list1[1][1]);
	g.drawLine(centerX+points_list1[2][0],centerY+points_list1[2][1],centerX+points_list1[3][0],centerY+points_list1[3][1]);
	g.drawLine(centerX+points_list1[4][0],centerY+points_list1[4][1],centerX+points_list1[5][0],centerY+points_list1[5][1]);
	
	
    rotate(points_list1, size1,0,0, 60);
	g.drawLine(centerX+points_list1[0][0],centerY+points_list1[0][1],centerX+points_list1[1][0],centerY+points_list1[1][1]);
	g.drawLine(centerX+points_list1[2][0],centerY+points_list1[2][1],centerX+points_list1[3][0],centerY+points_list1[3][1]);
	g.drawLine(centerX+points_list1[4][0],centerY+points_list1[4][1],centerX+points_list1[5][0],centerY+points_list1[5][1]);
	
		
	}
	}
/*<applet code="rotation.class" width="1000" height="1000"></applet>*/