import java.util.*;
import java.awt.*;
import java.applet.*;
public class first extends Applet
{
	int centerX,centerY,maxX,maxY;
	
	void intrg()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	void dda(Graphics g,int x1,int y1,int x2,int y2)
	{
		double dx,dy,steps;
		
		dx=x2-x1;
		dy=y2-y1;
		
		if(Math.abs(dx)>Math.abs(dy))
		{
			steps=Math.abs(dx);
		}
		else
		{
			steps=Math.abs(dy);
		}
		
		double Xinc,Yinc;
		
		Xinc=dx/steps;
		Yinc=dy/steps;
		
		double x,y;
		x=x1;
		y=y1;
		
		for(int i=0;i<steps;i++)
		{
			g.fillOval((int)x,(int)y,5,5);
			x=x+Xinc;
			y=y+Yinc;
		}
	}
	
	void scale(Graphics g,int x[],int y[],int sx,int sy)
	{
		for(int i=0;i<x.length;i++)
		{
			x[i]=x[i]*sx;
			y[i]=y[i]*sy;
		}
		
		for(int i=0;i<x.length;i++)
		{
			if(i==x.length-1)
			{
				dda(g,x[i],y[i],x[0],y[0]);
			}
			else
			{
				dda(g,x[i],y[i],x[i+1],y[i+1]);
			}
		}
	}
	
	public void paint(Graphics g)
	{
		intrg();
		/*
		dda(g,centerX,centerY,centerX+100,centerY);
		dda(g,centerX,centerY,centerX-100,centerY);
		dda(g,centerX,centerY,centerX,centerY+100);
		dda(g,centerX,centerY,centerX,centerY-100);
		dda(g,centerX,centerY,centerX+100,centerY+100);
		dda(g,centerX,centerY,centerX+100,centerY-100);
		dda(g,centerX,centerY,centerX-100,centerY+100);
		dda(g,centerX,centerY,centerX-100,centerY-100);
		dda(g,centerX,centerY,centerX+100,centerY+300);
		dda(g,centerX,centerY,centerX+300,centerY+100);
		dda(g,centerX,centerY,centerX+100,centerY-300);
		dda(g,centerX,centerY,centerX+300,centerY-100);
		dda(g,centerX,centerY,centerX-100,centerY+300);
		dda(g,centerX,centerY,centerX-300,centerY+100);
		dda(g,centerX,centerY,centerX-100,centerY-300);
		dda(g,centerX,centerY,centerX-300,centerY-100);*/
		
		int x[]={0,100,100,0};
		int y[]={0,0,100,100};
		for(int i=0;i<x.length;i++)
		{
			if(i==x.length-1)
			{
				dda(g,x[i],y[i],x[0],y[0]);
			}
			else
			{
				dda(g,x[i],y[i],x[i+1],y[i+1]);
			}
		}
		
		scale(g,x,y,5,6);
		
	}
}