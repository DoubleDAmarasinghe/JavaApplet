import java.util.*;
import java.awt.*;
import java.applet.*;
public class scale2 extends Applet
{
	int centerX,centerY,maxX,maxY;
	
	void intrg()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	void dda(Graphics g,int x1,int y1,int x2,int y2)
	{
		double dx,dy,steps;
		
		dx=x2-x1;
		dy=y2-y1;
		
		if(Math.abs(dx)>Math.abs(dy))
		{
			steps=Math.abs(dx);
		}
		else
		{
			steps=Math.abs(dy);
		}
		
		double Xinc,Yinc;
		
		Xinc=dx/steps;
		Yinc=dy/steps;
		
		double x,y;
		x=x1;
		y=y1;
		
		for(int i=0;i<steps;i++)
		{
			g.fillOval((int)x,(int)y,5,5);
			x=x+Xinc;
			y=y+Yinc;
		}
	}
	
	void scale(Graphics g,int x[],int y[],int sx,int sy)
	{
		for(int i=0;i<x.length;i++)
		{
			x[i]=x[i]*sx;
			y[i]=y[i]*sy;
		}
		
		for(int i=0;i<x.length-1;i++)
		{
			if(i==x.length-1)
			{
				dda(g,x[i],y[i],x[0],y[0]);
			}
			else
			{
				dda(g,x[i],y[i],x[i+1],y[i+1]);
			}
		}
	}
	
	public void paint(Graphics g)
	{
		intrg();
		/*int x1[]={0,100,100,0};
		int y1[]={0,0,100,100};*/
		
		int x2[]={centerX-50,centerX-50,centerX-20,centerX-20,centerX-50,centerX-35,centerX-20};
		int y2[]={centerY,centerY+20,centerY+20,centerY,centerY,centerY-10,centerY};
		
		
		
		/*for(int i=0;i<x1.length;i++)
		{
			if(i==x1.length-1)
			{
				dda(g,x1[i],y1[i],x1[0],y1[0]);
			}
			else
			{
				dda(g,x1[i],y1[i],x1[i+1],y1[i+1]);
			}
		}
		
		scale(g,x1,y1,5,6);*/
		
		for(int i=0;i<x2.length-1;i++)
		{
			if(i==x2.length-1)
			{
				dda(g,x2[i],y2[i],x2[0],y2[0]);
			}
			else
			{
				dda(g,x2[i],y2[i],x2[i+1],y2[i+1]);
			}
		}
		scale(g,x2,y2,3,5);
	}
}