import java.util.*;
import java.awt.*;
import java.applet.*;
public class translate1 extends Applet
{
	void Line(Graphics g,int x1,int y1,int x2,int y2)
	{
		float dx,dy,steps;
		dx=x2-x1;
		dy=y2-y1;
		
		if(Math.abs(dx)>Math.abs(dy))
		{
			steps=Math.abs(dx);
		}
		else
		{
			steps=Math.abs(dy);
		}
		
		float Xinc,Yinc,x,y;
		x=x1;
		y=y1;
		Xinc=dx/steps;
		Yinc=dy/steps;
		
		for(int i=0;i<steps;i++)
		{
			g.fillOval((int)x,(int)y,5,5);
			
			x=x+Xinc;
			y=y+Yinc;
		}
	}
	
	void point(Graphics g,int x,int y)
	{
		g.fillOval(x,y,10,10);
	}
	
	void translatePoint(int p[],int t[])
	{
		for(int i=0;i<p.length;i++)
		{
			p[i]=p[i]+t[i];
		}
		
	}
	
	void translateLine(int p[][],int t[])
	{
		for(int i=0;i<p.length;i++)
		{
			for(int n=0;n<p[i].length;n++)
			{
				p[i][n]=p[i][n]+t[i];
			}
		}
	}
	
	
	void translateRectangle(Graphics g,int p[][],int t[])
	{
		for(int i=0;i<p.length;i++)
		{
			for(int n=0;n<p[i].length;n++)
			{
				p[i][n]=p[i][n]+t[i];
			}
		}
		
		for(int i=0;i<p.length-1;i++)
		{
			for(int n=0;n<p[i].length-1;n++)
			{
				Line(g,p[i][n],p[i+1][n],p[i][n+1],p[i+1][n+1]);
			}
		}
	}
	
	
	
	public void paint(Graphics g)
	{
		/*Line(g,100,100,200,200);*/
		int p[]={100,100};
		point(g,p[0],p[1]);
		
		int t[]={50,100};
		translatePoint(p,t);
		point(g,p[0],p[1]);
		
		
		int p1[][]={{100,200},{100,200}};
		Line(g,p1[0][0],p1[1][0],p1[0][1],p1[1][1]);
		
		translateLine(p1,t);
		Line(g,p1[0][0],p1[1][0],p1[0][1],p1[1][1]);
		
		int p2[][]={{400,800,800,400},{400,400,200,200}};
		
		for(int i=0;i<p2.length-1;i++)
		{
			for(int n=0;n<p2[i].length-1;n++)
			{
				Line(g,p2[i][n],p2[i+1][n],p2[i][n+1],p2[i+1][n+1]);
			}
		}
		
		translateRectangle(g,p2,t);
		
	}
}