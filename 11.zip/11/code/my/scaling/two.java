import java.util.*;
import java.awt.*;
import java.applet.*;
public class two extends Applet
{
	int centerX,centerY,maxX,maxY;
	void intrg()
	{
		Dimension d;
		d=getSize();
		maxX=d.width;
		maxY=d.height;
		centerX=maxX/2;
		centerY=maxY/2;
	}
	
	void bresanhams(Graphics g,int x1,int y1,int x2,int y2)
	{
		int dx,dy,p,x,y;
		
		dx=Math.abs(x2-x1);
		dy=Math.abs(y2-y1);
		
		x=x1;
		y=y1;
		
		if(dx>dy)
		{
			p=2*dy-dx;
			if(x1<x2)
			{
				while(x<=x2)
				{
					g.fillOval((int)x,(int)y,5,5);
					x++;
					if(p<0)
					{
						p=p+2*dy;
					}
					else
					{
						p=p+2*dy-2*dx;
						y=getY(y1,y2,y);
					}
				}
			}
			else
			{
				while(x>=x2)
				{
					g.fillOval((int)x,(int)y,5,5);
					x--;
					if(p<0)
					{
						p=p+2*dy;
					}
					else
					{
						p=p+2*dy-2*dx;
						y=getY(y1,y2,y);
					}
				}
			}
		}
		else
		{
			p=2*dx-dy;
			if(y1<y2)
			{
				while(y<=y2)
				{
					g.fillOval((int)x,(int)y,5,5);
					y++;
					if(p<0)
					{
						p=p+2*dx;
					}
					else
					{
						p=p+2*dx-2*dy;
						x=getX(x1,x2,x);
					}
				}
			}
			else
			{
				while(y>=y2)
				{
					g.fillOval((int)x,(int)y,5,5);
					y--;
					if(p<0)
					{
						p=p+2*dx;
					}
					else
					{
						p=p+2*dx-2*dy;
						x=getX(x1,x2,x);
					}
				}
			}
		}
	}
	
	void scale(Graphics g,int x[],int y[],int sx,int sy)
	{
		for(int i=0;i<x.length;i++)
		{
			x[i]=x[i]*sx;
			y[i]=y[i]*sy;
		}
		
		for(int i=0;i<x.length;i++)
		{
			if(i==x.length-1)
			{
				bresanhams(g,x[i],y[i],x[0],y[0]);
			}
			else
			{
				bresanhams(g,x[i],y[i],x[i+1],y[i+1]);
			}
		}
	}
	
	int getY(int y1,int y2,int y)
	{
		if(y1<y2)
		{
			return y+1;
		}
		else if(y1>y2)
		{
			return y-1;
		}
		else
			return y;
	}
	
	int getX(int x1,int x2,int x)
	{
		if(x1<x2)
		{
			return x+1;
		}
		else if(x1>x2)
		{
			return x-1;
		}
		else
			return x;
	}
	
	
	public void paint(Graphics g)
	{
		intrg();
		/*bresanhams(g,centerX,centerY,centerX+100,centerY);
		bresanhams(g,centerX,centerY,centerX-100,centerY);
		bresanhams(g,centerX,centerY,centerX,centerY+100);
		bresanhams(g,centerX,centerY,centerX,centerY-100);
		bresanhams(g,centerX,centerY,centerX+100,centerY+100);
		bresanhams(g,centerX,centerY,centerX+100,centerY-100);
		bresanhams(g,centerX,centerY,centerX-100,centerY+100);
		bresanhams(g,centerX,centerY,centerX-100,centerY-100);
		bresanhams(g,centerX,centerY,centerX+100,centerY+300);
		bresanhams(g,centerX,centerY,centerX+300,centerY+100);
		bresanhams(g,centerX,centerY,centerX+100,centerY-300);
		bresanhams(g,centerX,centerY,centerX+300,centerY-100);
		bresanhams(g,centerX,centerY,centerX-100,centerY+300);
		bresanhams(g,centerX,centerY,centerX-300,centerY+100);
		bresanhams(g,centerX,centerY,centerX-100,centerY-300);
		bresanhams(g,centerX,centerY,centerX-300,centerY-100);*/
		
		/*int x[]={0,100,100,0};
		int y[]={0,0,100,100};
		for(int i=0;i<x.length;i++)
		{
			if(i==x.length-1)
			{
				bresanhams(g,x[i],y[i],x[0],y[0]);
			}
			else
			{
				bresanhams(g,x[i],y[i],x[i+1],y[i+1]);
			}
		}
		
		scale(g,x,y,5,6);
		*/
		
		int x[]={300,600,450};
		int y[]={300,300,0};
		
		for(int i=0;i<x.length;i++)
		{
			if(i==x.length-1)
			{
				bresanhams(g,x[i],y[i],x[0],y[0]);
			}
			else
			{
				bresanhams(g,x[i],y[i],x[i+1],y[i+1]);
			}
		}
		scale(g,x,y,1,6);
	}
}